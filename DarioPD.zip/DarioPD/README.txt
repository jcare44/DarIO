DarIO send notes values with osc to this patch pure data (gen_notes.pd).

-Open gen_notes on your machine or other (the machine should have audio output).
-Open in the same instance of pure data the synthetisers of your choise (+pdl_Midi_BassSaw_* ...).


